import java.awt.*;
import java.awt.event.*;
import java.applet.*;
public class demo extends Applet 
{
	public void init()
	{
	}
	public void paint(Graphics g)
	{
		g.drawString("Welcome Kalyani",100,100);
	}
}
